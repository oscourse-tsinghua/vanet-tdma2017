#!/bin/sh

exp=s

for exp in `ls ready`
do
	echo "$exp"
	ns ready/$exp &
	sleep 5
done
